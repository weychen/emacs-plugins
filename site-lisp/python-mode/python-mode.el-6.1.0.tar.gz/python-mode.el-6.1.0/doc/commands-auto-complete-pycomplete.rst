Python-mode commands

====================

